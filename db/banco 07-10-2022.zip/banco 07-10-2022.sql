-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.7.36 - MySQL Community Server (GPL)
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para salao
CREATE DATABASE IF NOT EXISTS `salao` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `salao`;

-- Copiando estrutura para tabela salao.agenda
CREATE TABLE IF NOT EXISTS `agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_profissional` int(11) NOT NULL,
  `id_servico` int(11) NOT NULL,
  `data` date NOT NULL,
  `hora` time NOT NULL,
  `nome` varchar(100) NOT NULL DEFAULT '0',
  `email` varchar(100) DEFAULT '0',
  `celular` char(20) DEFAULT '0',
  `cpf` char(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_agenda_servicos` (`id_servico`),
  KEY `FK_agenda_profissionais` (`id_profissional`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Nessa tabela seram armazenados os agendamentos dos clientes';

-- Copiando dados para a tabela salao.agenda: 5 rows
DELETE FROM `agenda`;
/*!40000 ALTER TABLE `agenda` DISABLE KEYS */;
INSERT INTO `agenda` (`id`, `id_profissional`, `id_servico`, `data`, `hora`, `nome`, `email`, `celular`, `cpf`) VALUES
	(1, 1, 1, '2022-10-06', '08:00:00', 'Willas', '0', '0', NULL),
	(2, 1, 2, '2022-10-06', '08:30:00', 'Willas', '0', '0', NULL),
	(3, 1, 3, '2022-10-06', '09:00:00', 'Willas', '0', '0', NULL),
	(4, 3, 2, '2022-10-06', '08:00:00', 'Lucas', '0', '0', NULL),
	(5, 4, 3, '2022-10-06', '08:30:00', 'Lucas', '0', '0', NULL);
/*!40000 ALTER TABLE `agenda` ENABLE KEYS */;

-- Copiando estrutura para tabela salao.profissionais
CREATE TABLE IF NOT EXISTS `profissionais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL DEFAULT '0',
  `dia_semana` char(20) DEFAULT NULL,
  `servicos` char(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela salao.profissionais: 4 rows
DELETE FROM `profissionais`;
/*!40000 ALTER TABLE `profissionais` DISABLE KEYS */;
INSERT INTO `profissionais` (`id`, `nome`, `dia_semana`, `servicos`) VALUES
	(1, 'NEGUIM', '0;1;2;3;4;5;6', '1;2;3'),
	(2, 'FÁBIO', '0;1;2;3;4;5;6', '1'),
	(3, 'NOEL', '0;1;2;3;4;5;6', '2'),
	(4, 'PRETIN', '0;1;2;3;4;5;6', '3');
/*!40000 ALTER TABLE `profissionais` ENABLE KEYS */;

-- Copiando estrutura para tabela salao.servicos
CREATE TABLE IF NOT EXISTS `servicos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) NOT NULL,
  `tempo` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela salao.servicos: 3 rows
DELETE FROM `servicos`;
/*!40000 ALTER TABLE `servicos` DISABLE KEYS */;
INSERT INTO `servicos` (`id`, `descricao`, `tempo`) VALUES
	(1, 'BARBA', '00:30:00'),
	(2, 'CABELO', '00:30:00'),
	(4, 'SOBRANCELHA', '00:30:00');
/*!40000 ALTER TABLE `servicos` ENABLE KEYS */;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
